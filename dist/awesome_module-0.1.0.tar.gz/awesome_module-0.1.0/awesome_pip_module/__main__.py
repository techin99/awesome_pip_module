from .awesome_module import awesome_module
awesome_module()